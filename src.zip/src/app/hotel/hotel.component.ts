import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css']
})
export class HotelComponent implements OnInit {

  hotelForm: any;
  hotels: any;
  constructor(private fb:FormBuilder, private hs:HotelService) { 
    this.hotelForm=this.fb.group({
      hotelId:[''],
      customerId:[''],
      hotelName:[''],
      city:[''],
      noOfRoomsAvailable:[''],

    });
  }

  ngOnInit(): void {
    this.getAllHotels();
    document.body.classList.add('bg-img');
  }

  getAllHotels() {
    this.hs.getAllHotels().subscribe((data) => {
      console.log(data);
      this.hotels = data;
    });
  }

  fnSelect(hotelId) {
    this.hs.findHotelById(hotelId).subscribe((data) => {
      console.log(data);
      // alert(JSON.stringify(data))
      this.hotelForm.patchValue(data);
    });
  }


  fnFind() {
    var hotelId = this.hotelForm.controls.hotelId.value;
    this.fnSelect(hotelId);
  }

  fnAdd() {
    var hotel = this.hotelForm.value;
    // this.bs.addHotel(hotel).subscribe(this.fnCallBack);    
    this.hs.addHotel(hotel).subscribe((data) => {
      console.log(data);
      this.getAllHotels();
    });
  }
  fnModify() {
    var hotel = this.hotelForm.value;
    this.hs.modifyHotel(hotel).subscribe((data) => {
      console.log(data);
      this.getAllHotels();
    });
  }
  fnDelete() {
    var hotelId = this.hotelForm.controls.hotelId.value;
    this.hs.deleteHotel(hotelId).subscribe((data) => {
      console.log(data);
      this.getAllHotels();
    });
  }

}
