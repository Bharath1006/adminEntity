import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  url:string='http://localhost:8080/admin/';

  constructor(private http:HttpClient) { }

  
  getAllAdmins()
  {
    return this.http.get(this.url);
  }

  findAdminById(aid:string)
  {
    return this.http.get(this.url+aid);
  }

  addAdmin(admin:any)
  {
    return this.http.post(this.url,admin);
  }

  modifyAdmin(admin:any)
  {
    return this.http.put(this.url,admin);
  }

  deleteAdmin(aid:string)
  {
    return this.http.delete(this.url+aid);
  }
}