import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HotelService {

  url:string='http://localhost:8080/hotel/';

  constructor(private http:HttpClient) { }

  
  getAllHotels()
  {
    return this.http.get(this.url);
  }

  findHotelById(hid:string)
  {
    return this.http.get(this.url+hid);
  }

  addHotel(hotel:any)
  {
    return this.http.post(this.url,hotel);
  }

  modifyHotel(hotel:any)
  {
    return this.http.put(this.url,hotel);
  }

  deleteHotel(hid:string)
  {
    return this.http.delete(this.url+hid);
  }
}
